#ifndef NYASH_CHILD_HANDLER_H
#define NYASH_CHILD_HANDLER_H

#include <sys/wait.h>

void child_handler(int signum);

#endif //NYASH_CHILD_HANDLER_H
