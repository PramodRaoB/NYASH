#ifndef NYASH_SYSCOMMANDS_H
#define NYASH_SYSCOMMANDS_H

#include "../utils/vector.h"

int exec_sys_command(vector *tokens);

#endif //NYASH_SYSCOMMANDS_H
