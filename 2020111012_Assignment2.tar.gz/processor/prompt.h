#ifndef NYASH_PROMPT_H
#define NYASH_PROMPT_H

void display_prompt(int status);

#endif //NYASH_PROMPT_H
