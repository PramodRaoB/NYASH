#ifndef NYASH_INIT_H
#define NYASH_INIT_H
#include "../globals.h"

void initialize_shell(void);

#endif //NYASH_INIT_H
