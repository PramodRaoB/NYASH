#ifndef NYASH_TOKENIZE_H
#define NYASH_TOKENIZE_H

#include "vector.h"

vector *tokenize_command(char *inputBuffer);
vector *tokenize_input(char *inputBuffer);

#endif //NYASH_TOKENIZE_H
