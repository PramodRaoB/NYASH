#ifndef NYASH_JOBS_H
#define NYASH_JOBS_H

#include "../utils/vector.h"
#include "../globals.h"

int _jobs(vector *tokens);

#endif //NYASH_JOBS_H
