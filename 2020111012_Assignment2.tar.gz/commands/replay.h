#ifndef NYASH_REPLAY_H
#define NYASH_REPLAY_H

#include "../globals.h"
#include "../utils/vector.h"

int replay(vector *tokens);

#endif //NYASH_REPLAY_H
