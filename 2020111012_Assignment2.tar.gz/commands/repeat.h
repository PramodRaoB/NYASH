#ifndef NYASH_REPEAT_H
#define NYASH_REPEAT_H

#include "../utils/vector.h"

int repeat(vector *tokens);

#endif //NYASH_REPEAT_H
