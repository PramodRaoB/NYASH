#ifndef NYASH_BAYWATCH_H
#define NYASH_BAYWATCH_H

#include "../utils/vector.h"

int baywatch(vector *tokens);

#endif //NYASH_BAYWATCH_H
