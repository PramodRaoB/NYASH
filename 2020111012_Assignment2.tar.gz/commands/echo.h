#ifndef NYASH_ECHO_H
#define NYASH_ECHO_H

#include "../utils/vector.h"

int echo(vector *tokens);

#endif //NYASH_ECHO_H
