#ifndef NYASH_PWD_H
#define NYASH_PWD_H

#include "../utils/vector.h"

int pwd(vector *tokens);

#endif //NYASH_PWD_H
