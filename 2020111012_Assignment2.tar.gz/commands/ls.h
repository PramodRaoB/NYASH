#ifndef NYASH_LS_H
#define NYASH_LS_H

#include "../utils/vector.h"

int ls(vector *tokens);

#endif //NYASH_LS_H
