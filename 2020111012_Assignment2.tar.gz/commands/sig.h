#ifndef NYASH_SIG_H
#define NYASH_SIG_H

#include "../utils/vector.h"

int sig(vector *tokens);

#endif //NYASH_SIG_H
