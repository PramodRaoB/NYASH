#ifndef NYASH_PINFO_H
#define NYASH_PINFO_H

#include "../utils/vector.h"
int pinfo(vector *tokens);

#endif //NYASH_PINFO_H
