#ifndef NYASH_BG_H
#define NYASH_BG_H

#include "../utils/vector.h"

int bg(vector *tokens);

#endif //NYASH_BG_H
