#ifndef NYASH_FG_H
#define NYASH_FG_H

#include "../utils/vector.h"

int fg(vector *tokens);

#endif //NYASH_FG_H
