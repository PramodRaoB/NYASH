#ifndef NYASH_CD_H
#define NYASH_CD_H

#include "../utils/vector.h"

int cd(vector *tokens);

#endif //NYASH_CD_H
